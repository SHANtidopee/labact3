
import java.util.Scanner;

public class two {

	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
        System.out.print("Enter a word: " );
        String word = input.next();
        System.out.println("Output:" + allStar(word));
        
        
	}
	public static String allStar(String str) {
		  if (str.length() <= 1) return str;
		  return str.charAt(0) + "*" + allStar(str.substring(1));
		}

	}


