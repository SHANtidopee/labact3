
import java.util.Scanner;

public class three {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int Num = sc.nextInt();
	    System.out.println("Output:\t" + BunnyEars(Num));
	       
		
	}
	public static int BunnyEars(int bunnies) {
		  if(bunnies == 0) return 0;
		  return 2 + BunnyEars(bunnies-1);
		}
		

	}

