
import java.util.Scanner;

public class four {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a words: ");
		String words = input.next();
		System.out.println("Output:\t" + changeXY(words));
		
	}
	public static String changeXY(String str) {
		if (str.length() == 0) return "";
		if (str.charAt(0) == 'x') return "y" + changeXY(str.substring(1));
		return str.charAt(0) + changeXY(str.substring(1));
	}
	
	}


