

import java.util.Scanner;

public class one {
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       System.out.print("Enter a number: ");
       int number = input.nextInt();
       System.out.print("Output:\t" + sumDigit(number));
        
    }

    public static int sumDigit(int n) {
        if (n == 0) {
            return 0;
        } else {
        	return n % 10 + sumDigit(n / 10);
        }
    }
}